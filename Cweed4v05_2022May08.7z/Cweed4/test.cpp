namespace { 
        void MyFunction( int fred ) /* COMMENT */
        {
            {
            }
        }
}